#!/bin/bash
colcon build --packages-select yesense_interface

