#!/bin/bash

#


# setup env
. install/setup.bash

# 使用 launch 文件运行
ros2 launch yesense_std_ros2 yesense_node.launch.py

